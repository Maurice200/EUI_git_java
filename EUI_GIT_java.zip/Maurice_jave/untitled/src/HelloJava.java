public class HelloJava {
    public void printHelloWorld() {
        System.out.println("Hello World");
    }
}
