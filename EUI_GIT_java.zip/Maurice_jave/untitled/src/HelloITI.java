public class HelloITI {
    public void printHelloITI() {
        System.out.println("Hello ITI");
    }

    public void printHelloGit() {
        System.out.println("Hello Git");
    }
}
