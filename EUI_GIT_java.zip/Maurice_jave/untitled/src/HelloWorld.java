public class HelloWorld {
    public void printHelloWorld() {
        System.out.println("Hello World");
    }
}
